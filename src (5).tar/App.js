import React from "react";
import { Chart } from "react-charts";
import "./App.css";
import { CompactTable } from "@table-library/react-table-library/compact";
import {
  ChartComponent,
  SeriesCollectionDirective,
  SeriesDirective,
  Inject,
  Legend,
  Category,
  Tooltip,
  DataLabel,
  LineSeries,
} from "@syncfusion/ej2-react-charts";
const dataVal = [
  {
    Id: 1,
    Year: 2004,
    Medals: 1,
  },
  {
    Id: 2,
    Year: 2008,
    Medals: 3,
  },
  {
    Id: 3,
    Year: 2012,
    Medals: 6,
  },
  {
    Id: 4,
    Year: 2016,
    Medals: 2,
  },
  {
    Id: 5,
    Year: 2020,
    Medals: 7,
  },
];

const MyChart = () => {
  //for the table props
  const nodes = dataVal;

  const COLUMNS = [
    { label: "ID", renderCell: (item) => item.Id },
    {
      label: "YEAR",
      renderCell: (item) => item.Year,
    },
    { label: "MEDALS", renderCell: (item) => item.Medals },
  ];
  const data = React.useMemo(
    () => [
      {
        label: "Series 1",
        data: dataVal.map((each) => [each.Year, each.Medals]),
      },
    ],
    []
  );

  //for the chart props

  const axes = React.useMemo(
    () => [
      { primary: true, type: "linear", position: "bottom", title: "year" },
      { type: "linear", position: "left", title: "year" },
    ],
    []
  );

  const dataTable = { nodes };

  return (
    <div className="chart-cont">
      <p>
        Name: Tarra Madhava
        Rao,No:8096765407,e-Mail:tarramadhavarao051@gmail.com
      </p>
      <h1>Data Table</h1>
      <div>
        <CompactTable columns={COLUMNS} data={dataTable} />
      </div>
      <h1>Data Chart</h1>
      <div
        style={{
          width: "450px",
          height: "300px",
        }}
      >
        <Chart data={data} axes={axes} />
      </div>
      <h1>Data Chart</h1>

      <div>
        <ChartComponent id="charts">
          <Inject
            services={[LineSeries, Legend, Tooltip, DataLabel, Category]}
          />
          <SeriesCollectionDirective>
            <SeriesDirective
              dataSource={dataVal}
              xName="Year"
              yName="Medals"
              width={2}
              name="Year"
              type="Line"
            ></SeriesDirective>
          </SeriesCollectionDirective>
        </ChartComponent>
      </div>
    </div>
  );
};

export default MyChart;
